public class TemperatureGraph
{
   public static void main(String[] args) 
   {   
      int temperatureDay1 = 21;
      int temperatureDay2 = 22;
      int temperatureDay3 = 28;
      int temperatureDay4 = 30;
      int temperatureDay5 = 18;
      int temperatureDay6 = 10;
      
      PointGraphWriter e = new PointGraphWriter();
      e.setAxes(50, 110, 300, "5", "40");
      int scale_factor = 3;
      e.setPoint1(temperatureDay1*scale_factor);
      e.setPoint2(temperatureDay2*scale_factor);
      e.setPoint3(temperatureDay3*scale_factor);
      e.setPoint4(temperatureDay4*scale_factor);
      e.setPoint5(temperatureDay5*scale_factor);
      e.setPoint6(temperatureDay6*scale_factor);
   }
}